const request = require('supertest');
const app = require('../backend/server'); // or wherever your Express app is exported

describe('something', () => {
  test('does a thing', () => {
    expect(true).toBe(true);
  });
});

describe('GET /', () => {
  it('should return JSON with message "API running..."', async () => {
    const res = await request(app).get('/');
    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ message: 'API running...' });
  });
});